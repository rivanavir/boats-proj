jQueryCSSSlider
===============

jQuery animated carousel / slide show using CSS transitions. Easily styled and animated using CSS (no Javascript animations).

[Click here](http://dwarcher.github.io/jQueryCSSSlider/) for documation and example.

License
-------
Available under the MIT license.
